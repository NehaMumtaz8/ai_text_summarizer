"""
Test harness for app.py.

app.py still imports heavy ML dependencies (torch, transformers,
google-generativeai) at module load time. Those aren't available in a
CI-style test environment, so we stub them out BEFORE importing app.py.
This lets us exercise the real Flask routes untouched.

Unlike before, there is no MongoDB to fake anymore — app.py is now a
stateless AI backend (BART / Gemini / PDF extraction only). Accounts
and history live in the browser via static/js/storage.js, which is
tested separately in tests/test_storage.js (a plain Node script).
"""
import sys
import types
import pytest


@pytest.fixture
def app(monkeypatch):
    fake_torch = types.ModuleType("torch")
    fake_torch.cuda = types.SimpleNamespace(is_available=lambda: False)
    sys.modules.setdefault("torch", fake_torch)

    fake_transformers = types.ModuleType("transformers")
    fake_transformers.pipeline = lambda *a, **k: (lambda text, **kw: [{"summary_text": "stubbed summary"}])
    sys.modules.setdefault("transformers", fake_transformers)

    fake_genai = types.ModuleType("google.generativeai")
    fake_genai.configure = lambda **k: None
    fake_genai.GenerativeModel = lambda *a, **k: types.SimpleNamespace(
        start_chat=lambda: types.SimpleNamespace(
            send_message=lambda msg: types.SimpleNamespace(text="stubbed reply")
        )
    )
    fake_google = types.ModuleType("google")
    fake_google.generativeai = fake_genai
    sys.modules.setdefault("google", fake_google)
    sys.modules.setdefault("google.generativeai", fake_genai)

    monkeypatch.setenv("SECRET_KEY", "test-secret")
    monkeypatch.setenv("GEMINI_API_KEY", "fake-key-for-tests")

    sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parents[1]))

    import importlib
    if "app" in sys.modules:
        importlib.reload(sys.modules["app"])
        app_module = sys.modules["app"]
    else:
        app_module = importlib.import_module("app")

    app_module.app.config.update(TESTING=True)
    yield app_module.app


@pytest.fixture
def client(app):
    return app.test_client()
